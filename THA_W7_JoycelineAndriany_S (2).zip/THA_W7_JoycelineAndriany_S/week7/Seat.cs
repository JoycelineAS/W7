﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace week7
{
    internal class Seat
    {

        public bool available { get; set; }
        public string col { get; set; }
        public string row { get; set; }
        public Button btn { get; set; }

        public Seat(bool available, string col, string row)
        {
            this.available = available;
            this.col = col;
            this.row = row;
        }
    }
}
