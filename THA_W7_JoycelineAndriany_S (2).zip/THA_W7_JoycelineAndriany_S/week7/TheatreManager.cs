﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week7
{
    internal class TheatreManager {

        public List<MovieTime> movieTimes { get; set; }
        public List<Movie> movies { get; set; }



        public TheatreManager()
        {
            this.movieTimes = new List<MovieTime>();
            this.movies = new List<Movie>();
            
            Movie movie1 = new Movie(PickMovie.judulfilm[0], "Horror" , PickMovie.directoryfilm[0]);
            this.movieTimes.Add(new MovieTime(movie1, "1" + (1) + ":" + "00"));
            movie1.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie1, "1" + (1 + 1) + ":" + "00"));
            movie1.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie1, "1" + (1 + 2) + ":" + "00"));
            movie1.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie1, "1" + (1 + 3) + ":" + "00"));
            movie1.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie1, "1" + (1 + 4) + ":" + "00"));
            movie1.time.Add(this.movieTimes.Last());
            movies.Add(movie1);

            Movie movie2 = new Movie(PickMovie.judulfilm[1], "Action/Adventure,Fantasy", PickMovie.directoryfilm[1]);
            this.movieTimes.Add(new MovieTime(movie2, "1" + (1) + ":" + "15"));
            movie2.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie2, "1" + (1 + 2) + ":" + "00"));
            movie2.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie2, "1" + (1 + 4) + ":" + "00"));
            movie2.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie2, "1" + (1 + 6) + ":" + "30"));
            movie2.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie2, "1" + (1 + 8) + ":" + "00"));
            movie2.time.Add(this.movieTimes.Last());
            movies.Add(movie2);

            Movie movie3 = new Movie(PickMovie.judulfilm[2], "Adventure,Comedy", PickMovie.directoryfilm[2]);
            this.movieTimes.Add(new MovieTime(movie3, "1" + (1) + ":" + "00"));
            movie3.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie3, "1" + (1 + 1) + ":" + "15"));
            movie3.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie3, "1" + (1 + 2) + ":" + "00"));
            movie3.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie3, "1" + (1 + 3) + ":" + "30"));
            movie3.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie3, "1" + (1 + 4) + ":" + "45"));
            movie3.time.Add(this.movieTimes.Last());
            movies.Add(movie3);

            Movie movie4 = new Movie(PickMovie.judulfilm[3], "Action,Adventure", PickMovie.directoryfilm[3]);
            this.movieTimes.Add(new MovieTime(movie4, "1" + (1) + ":" + "20"));
            movie4.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie4, "1" + (1 + 1) + ":" + "00"));
            movie4.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie4, "1" + (1 + 3) + ":" + "30"));
            movie4.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie4, "1" + (1 + 5) + ":" + "00"));
            movie4.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie4, "1" + (1 + 7) + ":" + "00"));
            movie4.time.Add(this.movieTimes.Last());
            movies.Add(movie4);

            Movie movie5 = new Movie(PickMovie.judulfilm[4], "Adventure,Comedy", PickMovie.directoryfilm[4]);
            this.movieTimes.Add(new MovieTime(movie5, "1" + (1) + ":" + "15"));
            movie5.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie5, "1" + (1 + 1) + ":" + "00"));
            movie5.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie5, "1" + (1 + 2) + ":" + "40"));
            movie5.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie5, "1" + (1 + 3) + ":" + "35"));
            movie5.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie5, "1" + (1 + 4) + ":" + "00"));
            movie5.time.Add(this.movieTimes.Last());
            movies.Add(movie5);

            Movie movie6 = new Movie(PickMovie.judulfilm[5], "Horror", PickMovie.directoryfilm[5]);
            this.movieTimes.Add(new MovieTime(movie6, "1" + (1) + ":" + "00"));
            movie6.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie6, "1" + (1 + 2) + ":" + "00"));
            movie6.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie6, "1" + (1 + 3) + ":" + "00"));
            movie6.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie6, "1" + (1 + 6) + ":" + "00"));
            movie6.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie6, "1" + (1 + 7) + ":" + "00"));
            movie6.time.Add(this.movieTimes.Last());
            movies.Add(movie6);

            Movie movie7 = new Movie(PickMovie.judulfilm[6], "Adventure", PickMovie.directoryfilm[6]);
            this.movieTimes.Add(new MovieTime(movie7, "1" + (2) + ":" + "00"));
            movie7.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie7, "1" + (1 + 3) + ":" + "00"));
            movie7.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie7, "1" + (1 + 4) + ":" + "00"));
            movie7.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie7, "1" + (1 + 5) + ":" + "00"));
            movie7.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie7, "1" + (1 + 6) + ":" + "00"));
            movie7.time.Add(this.movieTimes.Last());
            movies.Add(movie7);

            Movie movie8 = new Movie(PickMovie.judulfilm[7], "Comedy", PickMovie.directoryfilm[7]);
            this.movieTimes.Add(new MovieTime(movie8, "1" + (2) + ":" + "00"));
            movie8.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie8, "1" + (1 + 4) + ":" + "00"));
            movie8.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie8, "1" + (1 + 6) + ":" + "30"));
            movie8.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie8, "1" + (1 + 7) + ":" + "00"));
            movie8.time.Add(this.movieTimes.Last());
            this.movieTimes.Add(new MovieTime(movie8, "1" + (1 + 8) + ":" + "00"));
            movie8.time.Add(this.movieTimes.Last());
            movies.Add(movie8);

            

        }
        
    }
}
