﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace week7
{
    public partial class PickMovie : Form
    {
        TheatreManager theatreManager;
        public PickMovie()
        {
            InitializeComponent();
        }

        Panel movieList = new Panel();
        List<String> perantara = new List<String>();
        public static List<String> judulfilm = new List<String>();
        public static List<String> directoryfilm = new List<String>();
        private void PickMovie_Load(object sender, EventArgs e)
        {
            timer1.Start();

            string file = "textfilecinema.txt";
            string[] lines = File.ReadAllLines(file);
            perantara = new List<string>();
            foreach (string line in lines)
            {
                perantara.AddRange(line.Split(','));
            }
            judulfilm = new List<string>();
            directoryfilm = new List<string>();
            foreach (string baris in perantara)
            {
                if (baris[0] == 'C')
                {
                    directoryfilm.Add(baris);
                }
                else
                {
                    judulfilm.Add(baris);
                }
            }
            
            theatreManager = new TheatreManager();
            int y = 10;
            this.Controls.Add(movieList);
            movieList.Location = new Point(50, 50);
            movieList.Size = new Size(this.Width - 100, this.Height - 100);
            movieList.BackColor = Color.Aqua;
            movieList.AutoScroll = true;
            foreach (Movie movie in theatreManager.movies)
            {

                PictureBox pict = new PictureBox();
                pict.Image = Image.FromFile(movie.img);
                pict.SizeMode = PictureBoxSizeMode.StretchImage;
                int imgSize = 10;
                pict.Size = new Size(9 * imgSize, 16 * imgSize);
                pict.Location = new Point(10, y);

                Label lblTitle = new Label();
                lblTitle.Text = movie.title;
                int lblTitleSize = 10;
                lblTitle.Size = new Size(9 * imgSize, 9 * lblTitleSize / 2);
                lblTitle.Location = new Point(9 * imgSize + 10, y);
                int titleY = lblTitle.Location.Y + lblTitle.Size.Height;

                Label lblDesc = new Label();
                lblDesc.Text = movie.descr;
                int lblDescSize = 10;
                lblDesc.Size = new Size(9 * imgSize, 9 * lblDescSize / 2);
                lblDesc.Location = new Point(9 * imgSize + 10, titleY + 10);

                y += (16 * imgSize) + 10;

                int lblDescX = lblDesc.Location.X;
                int lblDescY = lblDesc.Location.Y + lblDesc.Size.Height;
                foreach (MovieTime movieTime in movie.time)
                {
                    Button btn = new Button();
                    btn.Text = movieTime.time;
                    btn.Location = new Point(lblDescX, lblDescY + 10);
                    lblDescX += 10 + btn.Size.Width;
                    movieList.Controls.Add(btn);
                    btn.Click += (ob, ev) =>
                    {
                        new ReserveSeat(theatreManager, movieTime).ShowDialog();
                    };
                }

                movieList.Controls.Add(pict);
                movieList.Controls.Add(lblTitle);
                movieList.Controls.Add(lblDesc);
            }
        }
    
            int i = 0;
            private void timer1_Tick(object sender, EventArgs e)
            {
                if (i % 5 == 0)
                {
                    cinema.ForeColor = Color.Red;
                }
                else if (i % 3 == 0)
                {
                    cinema.ForeColor = Color.Yellow;
                }
                else if (i % 2 == 0)
                {
                    cinema.ForeColor = Color.Cyan;
                }
                i++;
            }

            private void PickMovie_ReSize(object sender, EventArgs e)
            {
                movieList.Size = new Size(this.Width - 100, this.Height - 100);
            }
        }
    }



